## 1.2

[Detail](https://support.typora.io/What's-New-1.2/)

- Upgrade Mermaid library version.
- Support move and delete images.
- Undo a copy image operation will now also remove the copied image.
- Add new image uploader Picsee (macOS).
- Improve performance when document contains large set of images (macOS).
- Better encode detection (Windows / Linux).
- Add docker, py and code language alias, add stata, postgresql, hive syntax highlight.
- Other bug fix.

## 1.1.5

[Detail](https://support.typora.io/What's-New-1.1/)

- Add Malay language support.
- Add Slovenian language support.
- Fix typo and update translations in other languages.
- Allow create file when open non-exist file via command line.
- Allow create file when open target link that does not have existing file. 
- Allow open other files' anchor position directly via file link.
- More compact context menu under Windows / Linux.
- Support copy / cut while line when nothing is selected.
- Add option to disable or enable physics package.
- Allow pasting markdown with Command-Option-Shift-V on macOS.
- Support offline activation and provide web UI to manage used license code.
- Sign Windows executables and installers.
- Support default / theme font size for exported image.
- Ensure downloaded image has image file extension.
- Support loading local image files with user append hashes.
- Improve delete line and delete block logic.
- Improve delete current block and delete current line.
- Assign default shortcut keys for select range and delete range actions.
- Some bug fix.

## 1.0.0

🎉🎉🎉🎉🎉🎉🎉🎉🎉

[Detail](https://support.typora.io/What's-New-1.0/)

Typora is now finally out of beta, Thanks for all your support!

## 0.11.0 (beta)

[Detail](https://support.typora.io/What's-New-0.11/)

## 0.10.0 (beta)

[Detail](https://support.typora.io/What's-New-0.10/)

## 0.9.98 (beta)

[Detail](https://support.typora.io/What's-New-0.9.98/)

## 0.9.90 (beta)

[Detail](https://support.typora.io/What's-New-0.9.90/)

## 0.9.84 (beta)

[Detail](https://support.typora.io/What's-New-0.9.84/)

## 0.9.80 (beta)

[Detail](https://support.typora.io/What's-New-0.9.80/)

## 0.9.73 (beta)

[Detail](https://support.typora.io/What's-New-0.9.73/)

## 0.9.71 (beta)

[Detail](https://support.typora.io/What's-New-0.9.71/)

## 0.9.66 (beta)

[Detail](https://support.typora.io/What's-New-0.9.66/)

## 0.9.63 (beta)

[Detail](https://support.typora.io/What's-New-0.9.63/)

## 0.9.61 (beta)

[Detail](https://support.typora.io/What's-New-0.9.61/)

## 0.9.59 (beta)

[Detail](https://support.typora.io/What's-New-0.9.59/)

## 0.9.58 (beta)

[Detail](https://support.typora.io/What's-New-0.9.58/)

## 0.9.54 (beta)

[Detail](https://support.typora.io/What's-New-0.9.54/)